# XXT → FYQ Controller Handoff

## Decision
`PROMOTE_P3_AMPCORR_TO_M3_REPLAY`

Mathematical Review: `PASS WITH LIMITATION`

## What FYQ may do now
1. Freeze the selected `F1_K7` forecast artifact:
   - expected forecast SHA256: `ed198712edfbaddbd0f5d620a6f4dd5f976a49034836ad2b45bc6254a549de9a`
2. Run **one formal M3/SP replay** with only the forecast layer replaced by F1_K7.
3. Keep all other contracts unchanged.
4. Run the independent full validator.
5. Compare F1-M3 against F0-M3 under the same accounting.
6. Return to Controller / XXT before any Q2 re-freeze.

## What FYQ must not do
- do not rescan K;
- do not tune on Nov-Dec;
- do not alter q=0.80 in this branch;
- do not change S1-A / 5× emergency / SOC / power / eta / terminal rule;
- do not use Oracle as a deployable candidate;
- do not declare Q2 Frozen before M3 replay is validated.

## Limitation wording to carry forward
- Nov-Dec is a `pre-designated winter evaluation window`, not an untouched holdout.
- Exact K re-adjudication has the disclosed non-authoritative-replica provenance nuance.
- Early-Feb uses identity rho=1 until K legal post-Feb histories exist.
- This Phase B does not re-prove q=0.80.

## Integrity note
The current XXT upload did not include the 104 MB source-delivery ZIP. The review therefore relies on the internally hash-clean evidence snapshot plus independent lightweight recomputation. Before final promotion packaging, Controller should still verify the source delivery outer SHA256 equals:
`011f1d0d64e4aa578a1c5f377b26ac5585d9317f807f9ffe89132b462d48ea36`.

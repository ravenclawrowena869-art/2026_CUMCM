# XXT Causality Audit

## Verdict
`PASS WITH DISCLOSED PROVENANCE LIMITATION`

### A1
- latest legal complete day: `d-2` — PASS
- Sep-Oct exact-K history: PASS for K=7/14/28
- tuning latest-day violations: 0
- January admitted to amplitude history: 0
- K=7 first exact-K day: 2025-02-09
- K=7 prefix identity fallback count: 8
- Sep-Oct fallback: 0
- Nov-Dec fallback: 0
- rho clipping: none

### Historical P3 provenance
Formal F0 daily provenance count = 334.  
January residual days exist but are not admitted because the authority does not establish sufficient daily causal P3 generation provenance.

### A2
Nov-Dec is a **pre-designated winter evaluation window**, not an untouched holdout.

### A3
Each K×policy starts from Feb-01 SOC=6000 and carries its own realized SOC. No Sep-01 or Nov-01 reset is allowed. Evidence and full-year validators report exact continuity.

### A4
`eps_E=1e-9 kWh`, `relative_tie_tol=1e-6`, no rho clipping.

### Provenance nuance
The exact-runner K re-adjudication happened after earlier non-authoritative winter-replica outputs had been seen. This prevents a pristine independent-test claim, but the candidate set/rule did not change and exact re-adjudication still selects K=7 by a nontrivial margin. This is a limitation, not a causal leakage finding.

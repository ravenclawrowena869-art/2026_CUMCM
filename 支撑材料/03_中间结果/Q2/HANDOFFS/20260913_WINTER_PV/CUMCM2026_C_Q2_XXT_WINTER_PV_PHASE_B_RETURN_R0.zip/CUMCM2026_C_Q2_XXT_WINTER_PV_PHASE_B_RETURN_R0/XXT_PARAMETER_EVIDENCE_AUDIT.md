# XXT Parameter Evidence Audit

## K candidate set
`[7, 14, 28]` only — PASS.

## Objective
Sep-Oct combined `M1 total cost + M2 total cost` among hard-gate PASS candidates — PASS.

## Independent recompute

| K | M1 Sep-Oct | M2 Sep-Oct | Combined | Hard Gate |
|---:|---:|---:|---:|---|
| 7 | 2889561.33 | 2786412.16 | 5675973.49 | PASS |
| 14 | 2973708.25 | 2819646.98 | 5793355.24 | PASS |
| 28 | 3169817.29 | 2859274.53 | 6029091.82 | PASS |

Selected K = **7**.

The K=14 combined cost is 2.068% above K=7, so the `relative_tie_tol=1e-6` rule is not triggered.

## Evidence judgment
`PASS WITH LIMITATION`.

The exact-runner re-adjudication occurred after non-authoritative winter replica results had been seen, so Nov-Dec is not a pristine test set. However, there is no evidence that the candidate set, tuning window, objective, tie rule, or K value was altered to chase the later result.

This is sufficient for **M3 replay promotion**, not for claiming unbiased final generalization evidence.

## q=0.80
Out of scope and **not revalidated** by this audit.

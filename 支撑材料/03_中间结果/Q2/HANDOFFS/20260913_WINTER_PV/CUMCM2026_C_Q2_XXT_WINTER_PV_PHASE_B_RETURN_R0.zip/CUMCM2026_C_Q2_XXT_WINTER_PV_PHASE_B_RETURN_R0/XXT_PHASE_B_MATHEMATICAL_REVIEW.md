# XXT Phase B Mathematical / Causal Review

## Verdict

**Controller verdict: `PROMOTE_P3_AMPCORR_TO_M3_REPLAY`**  
**Mathematical Review: `PASS WITH LIMITATION`**

这只代表：`L2 + P3_AMPCORR_K7` 这个预测层已经有足够证据进入 **一次正式 M3/SP replay**。

这**不代表**：
- Q2 已重新 Freeze；
- q=0.80 已在本轮重新证明；
- M3 已经有新结果；
- Oracle 可以部署。

## 1. A1 因果历史

PASS。

协议实际使用最近 K 个“全部 144 个 target timestamp 都严格早于 d00”的完整历史日；canonical right-endpoint mapping 下最新合法日为 `d-2`。预检记录：
- K=7/14/28 在 Sep-Oct 都有 exact K 个合法 ratio；
- `latest_complete_day_violation_count = 0`；
- tuning fallback = 0；
- rho clipping = 0；
- January 日不进入 amplitude history。

K=7 第一个 exact-K 日为 2025-02-09，因此 Feb-01 至 Feb-08 使用 `rho=1`，与预注册 fallback 规则一致。Nov-Dec fallback=0。

## 2. A2 评价窗口

PASS WITH LIMITATION。

Nov-Dec 已正确标记为 **pre-designated winter evaluation window**，不能写成 untouched holdout / independent test set。

因为团队已经在 Stage A 看过冬季偏差，并且 exact frozen-runner re-adjudication 发生在更早的非权威 winter replica 输出之后，所以统计独立性不能夸大。

但这不足以否决 promotion：
- K 候选始终只有 7/14/28；
- selection rule 没变；
- tie rule 没变；
- exact runner 重裁仍选 K=7；
- K=7 比第二名的 combined Sep-Oct cost 低 **2.068%**，远大于 `1e-6` 的数值 tie 阈值。

因此该 provenance nuance 限制的是“独立测试”措辞，不是当前模型排序。

## 3. A3 SOC chronology

PASS。

每个 K×M1/M2 从 Feb-01 `SOC=6000` 开始自己的连续路径，只截取 Sep-Oct 成本用于 K-selection；Nov-Dec 从各自 Oct-31 SOC 继续，没有窗口 reset。

全年度 F1：
- 334 days / 48,096 slots；
- initial SOC = 6000 kWh；
- end SOC = 1200 kWh；
- cross-day continuity residual = 0。

## 4. A4 数值规则

PASS。

预注册配置：
- `eps_E = 1e-9 kWh`
- `relative_tie_tol = 1e-6`
- `rho_clip = null`

没有发现结果出来后再改阈值或 clip rho 的证据。

## 5. K=7 参数证据

PASS。

独立重算 Sep-Oct combined cost：
- K=7: 5675973.49 CNY
- K=14: 5793355.24 CNY
- K=28: 6029091.82 CNY

3 个候选 hard gate 全 PASS，argmin = K=7，CSV 中 combined cost 与重算最大差异 = 0 CNY。

## 6. Winter promotion

PASS。

Nov-Dec PV aggregate absolute bias：
- F0: 1025775.399 kWh
- F1: 61937.608 kWh
- reduction: 93.96%

M1：
- total cost 下降 2859659.90 CNY
- emergency cost 下降 3434070.28 CNY

M2：
- total cost 下降 2460570.80 CNY
- emergency cost 下降 3224454.00 CNY

七项 promotion condition 均为 true。

## 7. 334-day full-path evidence

PASS。

F1 M1：
- annual total = 16553582.70 CNY
- 相对 F0 下降 2645969.09 CNY (13.78%)

F1 M2：
- annual total = 15441831.24 CNY
- 相对 F0 下降 3035454.13 CNY (16.43%)
- emergency energy 从 1063979.28 降到 400425.94 kWh，下降 62.37%

两个 validator 都显示：
- SOC ∈ [1200,10800]；
- charge/discharge ≤ 833.333333 kWh/slot；
- simultaneous charge/discharge = 0；
- emergency charging = 0；
- fallback = 0；
- balance / SOC recursion / cost residual 都只在数值误差量级；
- Oct31→Nov01 bridge residual = 0。

## 8. Forecast metric cross-check

F1 只改 PV layer，load metrics 保持不变。

全年 PV：
- MAE 降低 38.95%
- RMSE 降低 35.06%
- WAPE 降低 38.95%

这和 winter downstream cost 改善方向一致。

## 9. Oracle

PASS — strictly isolated.

`ORACLE_DIAGNOSTIC_SUMMARY.json` 明确：
- `deployable=false`
- `DIAGNOSTIC_ONLY / FUTURE_LEAKAGE_BY_DESIGN`

O1/O2 没有进入 K-selection，也不能进入正式 deployable ranking。

## 10. q=0.80 边界

本 review **没有重新选择或重新证明 q=0.80**。

因此 promotion 只表示 forecast layer 有资格进入 M3 replay。后续 Q2 是否重新 Freeze，需要 M3 的正式 replay + validator + Controller 裁决。

## 11. Review-scope limitation

当前上传只包含 Fast Review 包，没有 104 MB 完整 FYQ Delivery ZIP。因此我没有假装完成：
- 完整 Delivery outer ZIP 的现场 SHA/CRC；
- F1 48,096-slot raw ledger 的再次逐行重算。

但是：
- Fast Review 包自身 SHA：37/37 PASS；
- snapshot 内 `FINAL_INDEPENDENT_VERIFICATION.json` = PASS、无 failed checks；
- F0 frozen reproduction、F1 annual validators、K-selection、winter comparison 在 snapshot 内互相一致；
- 本次独立轻量复算未发现冲突。

按任务的 Fast Review 规则，在不存在 evidence conflict 时，不为“更保险”重跑全年 optimizer。

## Final

**允许进入 M3 replay。不要重扫 K，不要改 q，不要 Freeze。**

# 05_SOURCE_LIMITATIONS

This bootstrap was assembled in the FYQ Controller window.

Directly available bytes included here:
- official 2026 C problem statement and attachments;
- Q1 Final Freeze Manifest R0;
- Q1 Final Paper Handoff R0;
- FYQ Q2 full-year execution task.

Important limitation:
The exact original XXT Q2 Mathematical Contract delivery ZIP and the exact FYQ Q2 Formal Spec Controller Review ZIP are not mounted as raw bytes in this current window, although their integrity, stable contract ID, hashes, and Controller-adjudicated semantics are recorded in current project evidence.

Therefore:
1. `04_Q2_CONTROLLER_SEALED_SNAPSHOT_R0.md` may bootstrap implementation/preflight.
2. It must not be treated as a byte-identical replacement for the original XXT contract.
3. If the Codex session can obtain the original Q2 authority package from the team, add it before formal result production.
4. If any needed formula/terminal rule/field semantics is not explicitly fixed by official sources + this snapshot + Q1 upstream authority, STOP with `HOLD_FOR_AUTHORITY`; do not infer.
5. Q2 cannot be Frozen from this session. Current-version XXT Mathematical Review remains mandatory after the returned implementation package.

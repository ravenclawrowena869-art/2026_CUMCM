# 00_START_HERE — CYQ Codex as FYQ Q2 execution worker

Purpose: run the FYQ Q2 full-year implementation on CYQ's Codex/Astra compute without changing role authority.

## Identity
This execution session MUST set:

`ACTIVE_ROLE=FYQ_TECHNICAL_ORCHESTRATOR`

The machine/account/API key belongs to CYQ, but this execution is **not** a CYQ_PAPER task. Role is determined by the task authority, not by whose Codex account runs it.

## Read order
1. Verify `SHA256SUMS.txt`.
2. Read `02_AUTHORITY_CHAIN.md`.
3. Fresh-read the canonical GitHub skill files listed in `03_CANONICAL_SKILL_FETCH_LIST.md`.
4. Read `04_Q2_CONTROLLER_SEALED_SNAPSHOT_R0.md`.
5. Read `01_FYQ_Q2_FULLYEAR_R0_TASK.md`.
6. Read `05_SOURCE_LIMITATIONS.md`.
7. Read official C problem and attachments under `official_C/`.
8. Read Q1 frozen upstream interface references under `authority/`.
9. Only then begin implementation.

## Hard boundaries
- No direct write to GitHub main.
- No merge.
- No paper editing.
- No change to Q1 Frozen model/result.
- No silent change to Q2 objective, accounting, hard constraints, information set, emergency 5× price, S1 semantics, or risk-policy definitions.
- Any conflict with original Q2 mathematical authority => STOP and report `HOLD_FOR_AUTHORITY`.
- Deliver a ZIP back to FYQ Controller. Do not self-Freeze Q2.

## Expected execution mode
Evidence-first implementation, full replay, tests, saved outputs, independent accounting recomputation, and complete handoff to FYQ/XXT.

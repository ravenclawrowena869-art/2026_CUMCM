# 06_RETURN_CONTRACT_TO_FYQ

Return one ZIP containing at minimum:
- exact code used
- tests
- configs
- input/provenance manifest
- data audit
- strategy summary
- daily summary
- slot-level results
- constraint replay
- accounting replay
- S1 audit
- alpha sensitivity
- delayed-actual sensitivity
- day-boundary diagnostic
- implementation report
- handoff to XXT
- SHA256SUMS.txt

Also include:
- outer ZIP SHA256
- ZIP CRC result
- clean rerun command
- runtime / package versions
- exact source file hashes
- list of any STOP/HOLD_FOR_AUTHORITY items

No GitHub merge or Q2 Freeze is authorized.

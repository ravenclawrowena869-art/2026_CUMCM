# 03_CANONICAL_SKILL_FETCH_LIST

Before implementation, fresh-read these files from:

Repository: `ravenclawrowena869-art/cumcm-rigorous-workflow`
Branch: current `main`

Mandatory:
1. `SKILL.md`
2. `skills/cumcm-rigorous-workflow/core/SHARED_CORE.md`
3. `skills/cumcm-rigorous-workflow/profiles/FYQ_TECHNICAL_ORCHESTRATOR.md`
4. `04_验收冻结/05_模型证据充分性Gate.md`
5. `03_建模与代码/05_参数选择协议.md`
6. `06_协作与交接/05_Paper_Handoff规范.md`
7. `06_协作与交接/06_三GPT协作与Skill共同维护.md`

If GitHub cannot be read, STOP and report the missing canonical source. Do not continue from memory.

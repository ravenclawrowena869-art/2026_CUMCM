# 04_Q2_CONTROLLER_SEALED_SNAPSHOT_R0

Status: `CONTROLLER_SEALED_EXECUTION_SNAPSHOT`
Purpose: bootstrap FYQ engineering execution on an isolated Codex session.
This file does NOT supersede the original XXT Mathematical Contract.

## Stable contract identity
- `Q2_MATH_CONTRACT_ID = CUMCM2026_C_Q2_MATH_CONTRACT_R1`
- `Q2_FORMAL_MATH_SPEC = PASS_WITH_LIMITATION`
- `Q2_FORMAL_RESULT = NOT_RUN`
- `Q2_FROZEN = FALSE`

The accepted XXT return package was previously verified with:
- ZIP SHA256: `0d17f99f58ef469369c0958ee4795bb3e71553289c60b8bf6c3d225f52e7e561`
- CRC: PASS
- top-level checksums: 23/23 PASS

The FYQ Controller Review package was previously verified with:
- SHA256: `d69fd9736a0a5736223e40f26211332534c31331afc834aa0e3ab5d0a325ccca`
- CRC: PASS
- internal checksums: 5/5 PASS

## Frozen execution semantics available to this bootstrap

### Day-ahead purchase
`POINT_DA_LP_R1`
- At 00:00, lock the normal-purchase commitment for the day.
- Information used at 00:00 must be available at 00:00.
- Do not use future actual load/PV values to create that commitment.

### Intraday recourse
`Q2_RH_FIXED_Q_LP_R1`
- Every 10 minutes, use information available at that time for storage recourse.
- The already-committed normal purchase is fixed.
- Any emergency balancing follows the official 5× emergency-purchase accounting.
- Same-slot actual information timing must later be stress-tested against `ONE_SLOT_DELAYED_ACTUAL`.

### Required baseline
`DAY_AHEAD_FIXED_STORAGE_WITH_SAFETY_OVERRIDE`

### Risk-aware candidate
`SIGNED_RESIDUAL_Q80_MARGIN_R1`

The analytic one-slot/no-storage anchor is:
`J(q)=p q + 5p E[(N-q)^+]`
which gives the candidate quantile condition:
`F_N(q)=0.8`.

This supports the rationale for alpha=0.8 as a risk-aware candidate only.
It does NOT prove global optimality for the full-year storage system.

### S1 completion assumption
`S1_A_PAID_UNUSED_NORMAL_ENERGY`

Use:
`q_used = q_committed - w`
with:
`0 <= w <= q_committed`.

Interpretation:
- all `q_committed` is paid at the normal planned-purchase price;
- `w` is committed normal energy ultimately not used by load/storage;
- no refund;
- no selling revenue;
- `w` must be tracked separately from PV curtailment.

Mandatory S1 audit:
- total w
- cost corresponding to committed-but-unused normal energy
- w / total committed ratio
- active slots
- active days
- maximum daily w
- strategy-wise distribution

If a strategy advantage materially depends on large w, flag:
`S1_DEPENDENT_ADVANTAGE`
and return for limitation/counterfactual adjudication.

## Mandatory pre-Freeze experiments
1. Same-slot actual recourse vs `ONE_SLOT_DELAYED_ACTUAL`.
2. 24 h truncation / day-boundary tail diagnostic.
3. Full replay for `alpha in {0.75, 0.80, 0.85}`.
4. Full S1 utilization audit.
5. Independent full-path SOC / energy / accounting replay.

## Claims
Default allowed quality levels:
- FEASIBLE only after hard constraints + independent accounting replay PASS.
- COMPETITIVE only after fair same-data/same-accounting baseline comparison.
- NEAR-OPTIMAL is forbidden unless a valid bound/gap/exact anchor exists for the claimed scope.

## STOP triggers
Stop and return to FYQ/XXT if any ambiguity affects:
- objective
- 5× emergency accounting
- normal-purchase commitment mutability
- information timing
- SOC or dynamic hard constraints
- S1 meaning
- terminal/day-boundary semantics
- parameter meaning or risk-policy definition

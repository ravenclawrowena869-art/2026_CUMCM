# 02_AUTHORITY_CHAIN

Use authority in this order:

1. Official 2026 CUMCM C problem statement, rules, templates, attachments.
2. Current formal project state / Frozen Source of Truth.
3. Current-version Mathematical Review / Q2 Math Contract.
4. Canonical `ravenclawrowena869-art/cumcm-rigorous-workflow` main.
5. FYQ Controller task/handoff.
6. Issue comments and working intermediate ideas.
7. Chat descriptions.

Important:
- Issue comments and `支撑材料/03_中间结果` are interaction/working-idea evidence. They do not automatically override formal authority.
- If a working idea conflicts with formal authority, do not choose whichever is newer-looking. Classify it and return it to FYQ/XXT.
- Q1 is technically Frozen for MODEL_AND_RESULT scope. It can reopen only for a confirmed P0.
- Q2 is released for implementation but is NOT Frozen.

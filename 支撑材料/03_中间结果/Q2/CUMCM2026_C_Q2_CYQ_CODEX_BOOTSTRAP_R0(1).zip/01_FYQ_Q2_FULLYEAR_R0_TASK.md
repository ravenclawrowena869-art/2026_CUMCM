# TASK — FYQ-Q2-FULLYEAR-R0
## Q2 全年策略实现、证据闭环与 Controller Delivery

角色：`FYQ_TECHNICAL_ORCHESTRATOR`  
优先级：P0  
执行状态：正式实现窗口  
前置状态：Q1 model/result 已 Frozen；Q2 full-year implementation 已释放。

## 0. First Action

每次实质性回答前 fresh 读取 canonical `cumcm-rigorous-workflow`：
1. `SKILL.md`
2. `skills/cumcm-rigorous-workflow/core/SHARED_CORE.md`
3. `skills/cumcm-rigorous-workflow/profiles/FYQ_TECHNICAL_ORCHESTRATOR.md`
4. `04_验收冻结/05_模型证据充分性Gate.md`
5. `03_建模与代码/05_参数选择协议.md`
6. 与本任务直接相关的 Q2 Formal Spec / Controller Review / official problem & attachments。

若将发生 GitHub 写操作，先 fresh 读取：
`06_协作与交接/06_三GPT协作与Skill共同维护.md`。

优先读取并校验正式 Q2 authority：
- `CUMCM2026_C_Q2_MATH_CONTRACT_R1`
- XXT Formal Opt Spec R1 delivery
- FYQ Controller Review
- 官方 C 题题面与 Q2 使用的附件
- Q1 Frozen storage/time/unit contract

任何文件不可访问时先列出缺口，不自行补猜。

## 1. Frozen Mathematical Contract

不得静默修改下列口径：

- `POINT_DA_LP_R1`：每天 00:00 锁定 normal purchase commitment。
- `Q2_RH_FIXED_Q_LP_R1`：执行期 normal purchase commitment 固定，储能按因果可得信息做 10 min recourse。
- baseline：`DAY_AHEAD_FIXED_STORAGE_WITH_SAFETY_OVERRIDE`。
- risk-aware candidate：`SIGNED_RESIDUAL_Q80_MARGIN_R1`。
- emergency purchase：按交易时刻电价的 `5×` 计费。
- Q80 只来自单槽无储能解析锚点 `F_N(q)=0.8`，不得宣称为带储能全年全局最优风险参数。
- S1：`S1_A_PAID_UNUSED_NORMAL_ENERGY`。
  `q_used = q_committed - w`, `0 <= w <= q_committed`；
  全部 `q_committed` 按正常计划购电计费；
  `w` 无退款、无售电收入，且与 PV curtailment 分离。
- Q1 Frozen storage contract 继续统一：10 min 时槽、能量单位、SOC recursion、SOC bounds、charge/discharge bounds、terminal treatment；若 Q2 contract 对跨日 SOC 另有明确规定，以 Q2 Formal Spec 为准并记录差异。

任何影响 objective、hard constraints、单位、accounting、information set 的改动必须停止并发 XXT Mathematical Review，不得自行“工程化修正”。

## 2. 唯一目标

真正跑通全年 Q2，建立从正式输入 → 每日 00:00 commitment → causal intraday recourse → emergency balance → 年度 accounting → strategy comparison → sensitivity / diagnostics → independent replay 的可追溯链。

本轮不 Freeze Q2。目标是产生可送 XXT current-version Mathematical Review 的 R0 candidate delivery。

## 3. Block A — Authority / Input Binding

必须先完成：

- 所有 Q2 官方输入文件 SHA256；
- Sheet / row / column / date range / slot range / unit audit；
- 每日 144 槽完整性；
- 缺失、重复、异常值和日期边界；
- 电价语义、normal / emergency 价格来源；
- forecast / actual / known_at 字段的信息时序；
- Q1→Q2 storage/time/unit interface mapping；
- 输出 `Q2_INPUT_MANIFEST.json` 与 `Q2_DATA_AUDIT.md`。

严禁 future-actual leakage。任何用于 00:00 commitment 的字段必须证明在 00:00 可得。

## 4. Block B — Core Solver / Replay Engine

代码至少分离：

- load/prepare
- day-ahead commitment policy
- intraday recourse solver
- validator
- accounting
- strategy runner
- export
- experiment/sensitivity

为每天和每槽记录：

- committed normal purchase
- used normal purchase
- `w` paid-unused normal energy
- emergency purchase
- load / PV / curtailment
- charge / discharge / SOC
- normal cost
- emergency cost
- total cost
- solver status / fallback reason
- known_at timestamp / information policy identifier

validator 必须逐槽 replay：
- energy balance
- SOC recursion
- bounds
- terminal / day-boundary contract
- commitment immutability
- emergency accounting
- `w` bounds and accounting separation
- no-selling contract
- max violation + argmax location

## 5. Block C — Required Strategies

同一输入、同一 accounting、同一硬约束下至少运行：

1. formal point/day-ahead strategy；
2. `DAY_AHEAD_FIXED_STORAGE_WITH_SAFETY_OVERRIDE` baseline；
3. `SIGNED_RESIDUAL_Q80_MARGIN_R1` candidate。

不得为不同策略使用不同输入版本、不同 emergency pricing 或不同 terminal rules。

每个策略产出：
- total annual cost
- normal purchase cost
- emergency purchase cost
- emergency energy
- `w` total / cost / ratio
- `w` active slots / days / max day
- PV curtailment
- charge/discharge throughput
- feasibility / violation summary
- runtime / failure count

## 6. Block D — Mandatory Pre-Freeze Experiments

这些不是可选项：

### D1. Information timing sensitivity
Formal current same-slot actual recourse 与：
`ONE_SLOT_DELAYED_ACTUAL`
做完整全年 replay。

比较：
- cost
- emergency energy/cost
- violations
- SOC behavior
- strategy ranking

### D2. 24 h truncation / day-boundary diagnostic
检查每日独立求解是否导致：
- 日末异常 SOC 操作；
- 次日首段异常；
- 末段 emergency spikes；
- tail advantage / disadvantage。

若发现 material effect，停止 Claim 升级并送 XXT。

### D3. Q80 neighborhood
对风险参数：
`alpha ∈ {0.75, 0.80, 0.85}`
全部重新生成 commitment 并做全年 full replay。

不得只在既有结果上事后算统计量。

### D4. S1 utilization audit
必须报告：
- `sum(w)`
- `cost(w)`
- `w / committed`
- active slots
- active days
- max daily w
- strategy-wise distribution

若 risk-aware candidate 的优势主要来自大量 paid-unused normal energy，必须显式标记 `S1_DEPENDENT_ADVANTAGE` 并补 counterfactual 或 limitation。

## 7. Baseline / Quality Claims

本轮默认只允许：
- `FEASIBLE`：hard constraints + independent accounting PASS；
- `COMPETITIVE`：同口径稳定优于合理 baseline 后才允许；
- `NEAR-OPTIMAL`：除非另有合法 bound/gap/exact anchor，不得使用。

Q80 的单槽解析推导不构成全年 near-optimal certificate。

## 8. Tests / Evidence

至少包含：

- unit tests for accounting and time-index mapping
- adversarial tests for oversupply + full battery
- future-information leakage tests
- emergency 5× price tests
- day-boundary tests
- `w` separation from PV curtailment
- saved-result independent replay
- fresh rerun
- clean-input rebuild
- strategy comparison consistency
- sensitivity full replay

所有主数字从输出文件独立复算一次。

## 9. Required Deliverables

交付一个完整 ZIP，至少包含：

- `00_START_HERE.md`
- `Q2_INPUT_MANIFEST.json`
- `Q2_DATA_AUDIT.md`
- source code
- tests
- configs
- `Q2_STRATEGY_SUMMARY.csv`
- `Q2_DAILY_SUMMARY.csv`
- `Q2_SLOT_LEVEL_RESULTS.*`
- `Q2_CONSTRAINT_REPORT.json`
- `Q2_ACCOUNTING_REPLAY.json`
- `Q2_S1_AUDIT.md`
- `Q2_ALPHA_SENSITIVITY.csv`
- `Q2_DELAYED_ACTUAL_SENSITIVITY.csv`
- `Q2_DAY_BOUNDARY_DIAGNOSTIC.md`
- `Q2_IMPLEMENTATION_REPORT.md`
- `HANDOFF_TO_XXT.md`
- `SHA256SUMS.txt`

ZIP 自身 SHA256、CRC、内部 checksums 一并报告。

## 10. Stop Conditions

出现以下任一情况立即停在 candidate，不得 Freeze：

- objective/accounting 与 Math Contract 不一致；
- future leakage；
- hard violation；
- emergency 5× price 实现不一致；
- S1 语义实现错误；
- day boundary 未定义或 materially 改变结论；
- alpha 邻域推翻主要结论；
- baseline 比较不公平；
- input/provenance 未绑定；
- current-version XXT Mathematical Review 尚未 PASS。

## 11. Git / Collaboration

默认不得直接改 main。
需要同步团队状态时：
- raw interaction → Issue #1 comment；
- 正式代码/支撑材料 → non-main branch + PR；
- 不自行 merge。

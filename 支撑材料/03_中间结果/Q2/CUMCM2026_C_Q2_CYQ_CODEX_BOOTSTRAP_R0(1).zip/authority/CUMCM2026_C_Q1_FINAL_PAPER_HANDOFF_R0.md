# CUMCM 2026 C题 Q1 Final Paper Handoff R0

模块：Q1 日内储能优化  
版本：`CUMCM2026_C_Q1_FREEZE_R0_20260911`  
Owner：FYQ Technical Orchestrator  
数学审核：XXT / Astra current-version PASS  
技术审核：FYQ fresh R2 review PASS  
Evidence Gate：`PASS_WITH_LIMITATION`  
Frozen Source：见 `CUMCM2026_C_Q1_FINAL_FREEZE_MANIFEST_R0.md`

## 【本问合同】

题目给出一天内 144 个 10 min 时段的小区负荷、光伏出力和购电价格，以及储能设备参数。需要在满足供需平衡、SOC、充放电功率和首末 SOC 等约束的条件下制定日内储能调度方案，并填写官方 result1。

统一时间尺度：`Δt=1/6 h`。原始功率 kW 先转换为每槽能量 kWh。时间合同固定为 `C_R1_RIGHT_ENDPOINT_ORDINAL_EXPORT`：raw `0:10` 为 slot 1，对应 `(00:00,00:10]`；raw `0:00+1` 为 slot 144，对应 `(23:50,24:00]`。result1 按 ordinal position 写入，不把显示标签重新解析为 solver 时间。

本问向后续问题提供：统一的储能状态方程、功率/能量单位合同、SOC 边界、终端状态处理和可独立 replay 的 LP 求解底座。

## 【本问中心逻辑】

核心困难有三点：

1. 同时存在功率量和能量量，需要用 10 min 时间尺度统一量纲；
2. 储能具有完整路径依赖，任何单槽错误都会沿 SOC 轨迹传播；
3. 购电费用最优解可能存在近等成本的退化轨迹，因此需要在不实质改变经济目标的前提下选择更简洁的充放电方案。

为此采用两阶段连续 LP。Stage 1 只优化全天购电费用；Stage 2 在 Stage-1 最优值上方仅允许极小 `epsilon_cost`，再最小化总充放电 throughput。这样保持正式经济目标，同时压制不必要的储能循环。

## 【方法】

正式主模型：`TWO_STAGE_CONTINUOUS_LP`。

选择连续 LP 的理由：题目中的购电量、充电量、放电量、弃光量和 SOC 均为连续量，能量平衡、SOC 递推、容量与功率限制都可以线性表达。为检查是否必须引入互斥 binary，另建立只增加充放电互斥变量的 MILP challenger。

独立对照得到：LP 与 mutex MILP 的 Stage-1 最优购电费用完全一致，MILP gap=0，LP 本身 simultaneous C/D=0，hard constraints 均通过。因此正式裁决为：

`LP_SUFFICIENT_MILP_AS_STRUCTURAL_VALIDATION`。

MILP 只承担结构验证，不作为第二套长期主模型。

## 【核心数学】

每个时段 `t=1,...,144` 定义：

- `g_t`：电网购电量，kWh；
- `c_t`：储能充电量，kWh；
- `d_t`：储能放电量，kWh；
- `u_t`：光伏弃电量，kWh；
- `E_t`：时段结束 SOC，kWh。

能量平衡：

`g_t + PV_t + d_t = L_t + c_t + u_t`。

SOC 递推：

`E_t = E_{t-1} + eta_c*c_t - d_t/eta_d`。

正式效率解释：

`eta_c = eta_d = 0.9`。

边界：

- `1200 <= E_t <= 10800 kWh`
- `0 <= c_t,d_t <= 5000/6 kWh`
- `0 <= u_t <= PV_t`
- `E_0 = E_144 = 6000 kWh`
- `g_t >= 0`，禁止售电。

Stage 1：

`min C = Σ_t p_t g_t`。

Stage 2：

`min Σ_t(c_t+d_t)`

subject to all Stage-1 hard constraints and

`Σ_t p_t g_t <= C* + epsilon_cost`，其中正式 `epsilon_cost=1e-4 CNY`。

## 【求解与伪代码包】

```text
Input: 144-slot load, PV, electricity price, storage parameters
Convert kW -> kWh with Δt=1/6 h
Freeze canonical slot_id = 1...144

Build continuous LP variables g,c,d,u,E
Add energy-balance constraints
Add SOC recursion and SOC bounds
Add charge/discharge power bounds
Add curtailment bounds
Add E0=E144=6000
Add g>=0 and no-selling contract

Stage 1:
    solve min Σ p_t g_t
    if not optimal: STOP_AND_ESCALATE
    store C*

Stage 2:
    add Σ p_t g_t <= C* + epsilon_cost
    solve min Σ(c_t+d_t)
    if not optimal: STOP_AND_ESCALATE
    if cost gap exceeds epsilon: STOP_AND_ESCALATE

Independent replay:
    recompute all 144 energy balances
    replay all 145 SOC states
    check min/max SOC, power bounds and terminal SOC
    recompute purchase cost
    check simultaneous charge/discharge

Structural challenger:
    add mutex binary z_t to the Stage-1 model
    solve MILP
    compare objective, feasibility, gap and simultaneous C/D

Export:
    write result1 by ordinal slot position
    reopen workbook from disk
    check 144 purchases, six 4h aggregates, SOC endpoints,
    sheet names, labels and unexpected modified cells

Output: frozen result1 workbook + validation evidence
```

## 【验证证据】

### Baseline

无储能基线费用：`48052.046590846665 CNY`。

正式 Stage-2 输出费用：`35126.948689289624 CNY`，减少 `12925.097901557041 CNY`，相对下降 `26.89812155476249%`。

### Exact / structural anchor

mutex MILP Stage-1：`35126.948589289634 CNY`，MIP gap=0；与 LP Stage-1 差值=0。

### Hard-constraint replay

- energy-balance max residual: `1.1368683772161603e-13 kWh`
- SOC-recursion max residual: `9.094947017729282e-13 kWh`
- SOC range: `[1200,10800] kWh`
- terminal SOC residual: `0`
- simultaneous C/D count: `0`

### epsilon sensitivity

对 `1e-6,1e-5,1e-4,1e-3,1e-2 CNY` 五个值分别重新求解。全部 Optimal、hard replay PASS、simultaneous C/D=0。

`1e-6...1e-3` 相对 `1e-4` 最大 SOC 差约 `0.0100847869 kWh`，最大 4h aggregate 差约 `0.0112053188 kWh`；`1e-2` wider stress 对应 `0.1109326561 kWh` 和 `0.1232585068 kWh`。未发现会改变 Q1 正文结论的结构性变化。

论文只能将该实验写成 retrospective confirmatory sensitivity。不得写成 `1e-4` 的全局最优性证明，也不得称其为求解器自身误差。

### efficiency semantics sensitivity

主结果采用 `eta_c=eta_d=0.9`。若把题面 90% 理解为 round-trip efficiency，并在对称损耗假设下取 `eta_c=eta_d=sqrt(0.9)`，重求解费用为 `33801.495642222006 CNY`，相对正式主口径约低 `3.7733%`，最大 SOC 点差约 `623.1144864419075 kWh`。

这一差异有实质解释意义。正文无需展开大表，但必须清楚写明正式 0.9/0.9 口径，并至少用一句简洁敏感性说明承认替代语义会改变数值结果。该要求来自 Mathematical Review，Paper Lead 不得将其完全降为不可见后台证据。

### result1 readback

- 144 purchase values: PASS
- six 4h charge/discharge pairs: PASS
- initial/final SOC: `6000/6000 kWh`
- labels / sheet names unchanged: PASS
- unexpected modified cells: none
- max purchase readback difference: `4.547473508864641e-13 kWh`

## 【核心结果】

Stage-1 exact optimum：`35126.948589289634 CNY`。

正式 Stage-2 导出调度费用：`35126.948689289624 CNY`。二者相差 `0.0001 CNY`，保留全精度时必须区分；按 2 位小数均为 `35126.95 CNY`。

No-storage baseline：`48052.046590846665 CNY`。正式 Stage-2 相比基线节省约 `26.90%`。

result1 六个 4h 区间充电量：

`[4500.000000, 833.333333, 4787.963043, 5286.035177, 0.000000, 5333.333333] kWh`

六个 4h 区间放电量：

`[0.000000, 6365.840192, 1702.996983, 91.101383, 5780.131883, 2859.868117] kWh`

首末 SOC 均为 `6000 kWh`。

## 【正式来源】

R2 delivery ZIP SHA256：

`a8acd57687c9a2380ab089e14c23bfec467dca7882b51f7777c9f97ed4977058`

输入附件 SHA256：

`66b87134f5ecccd68184d3539bb1293ef039f9e0fdd955a589b9bfa7f227c377`

Frozen result1 workbook：

`result1_candidate.xlsx`

SHA256：

`7aa49ebaeb506a25029c467cacd0c634138eda2f09e05e7527b287ae204cd964`

关键 evidence：

- `FINAL_R2_VERIFICATION.md`
- `Q1_EPSILON_SENSITIVITY_ADJUDICATION.md`
- `Q1_R2_DOCUMENT_RECONCILIATION.md`
- `FINAL_ENGINEERING_CLOSEOUT.md`
- `RESULT1_READBACK_REPORT.json`
- `RESULT1_MAPPING_AUDIT.csv`
- `results/q1_constraint_report.json`
- `results/q1_metrics.json`
- XXT current-version Mathematical Review bundle
- Blind Red Team numeric recomputation

## 【图表与表格】

建议保留少量直接服务结论的图表：

1. 日内负荷、光伏出力与电价特征图，用于解释储能套利的时序背景；
2. 正式调度的购电、充电、放电和 SOC 联合图，用于展示低价充电、高价放电及 SOC 约束；
3. no-storage vs storage 的费用对比表；
4. 若篇幅允许，用紧凑的小表或一句文字报告 epsilon sensitivity 与效率语义 sensitivity。

所有正式图表必须从 Frozen result1 / schedule 重新生成，不手工抄数字。

## 【自然语言初稿】

第一问首先将 10 min 时段内的负荷与光伏功率统一换算为能量，并以储能 SOC 作为跨时段状态变量。在此基础上建立连续线性规划，以全天购电费用最小为第一阶段目标。考虑到线性储能模型可能存在经济目标近乎等价但充放电轨迹不同的退化解，第二阶段在第一阶段最优费用上仅保留极小的 cost-preserving tolerance，并进一步最小化总充放电量，从而获得更简洁的调度轨迹。

为检查连续模型是否需要额外的充放电互斥整数变量，进一步建立仅增加互斥二元变量的 MILP 对照模型。独立求解表明，两种模型的第一阶段最优购电费用均为 35126.948589 CNY，MILP gap 为 0，且连续 LP 的最优解本身没有出现同时充放电，因此整数变量没有带来目标值或可行性增益，最终保留结构更简洁的两阶段连续 LP。

按照正式效率口径 `eta_c=eta_d=0.9` 求解后，第二阶段导出调度的购电费用为 35126.948689 CNY。与无储能基线 48052.046591 CNY 相比，费用下降约 26.90%。全过程独立 replay 显示能量平衡和 SOC 递推残差均处于 `1e-12 kWh` 量级，SOC 始终位于 `[1200,10800] kWh`，首末均为 6000 kWh，并且没有同时充放电。

对于第二阶段人为设置的 `epsilon_cost=1e-4 CNY`，在 `1e-6` 至 `1e-2 CNY` 的五个数量级上分别重新求解，核心调度结论未出现实质反转，因此该固定容差可作为稳定的数值设计使用。与此同时，若把 90% 效率解释为 round-trip efficiency 并采用对称的 `sqrt(0.9)` 单程效率，最优费用会发生约 3.77% 的变化。因此正文需要明确本文采用 0.9/0.9 的单程效率解释，并将另一解释作为参数语义敏感性的边界说明。

## 【论文禁区】

- 不得写“两阶段 LP 保证唯一解”。Stage 2 只选择更小 throughput 的近等成本轨迹。
- 不得把 `epsilon_cost=1e-4` 写成 solver intrinsic numerical tolerance。
- 不得声称 `1e-4` 是全局最优 epsilon。
- 不得声称 LP 数学上自动禁止同时充放电；当前结论来自正式求解结果 + MILP structural validation。
- 不得写 MILP 明显优于 LP；本题证据支持 LP 足够。
- 不得把 `eta_c=eta_d=0.9` 写成学界唯一效率解释。
- 不得完全隐藏 sqrt(0.9) sensitivity；至少需要一句受限说明。
- 不得把 `10:00-10:10` 等 `q1_paper_interval_candidates.csv` 中标记 `CANDIDATE_QUERY_NOT_PAPER_FACT` 的查询值当作 Frozen paper facts。
- 不得重新解析 result1 显示标签改变 slot mapping。
- 不得把 Stage-1 exact optimum 与 Stage-2 exported cost 在全精度下混成同一个数字。
- 当前 Linux cross-environment `verify_delivery --clean` 的 JSON byte-identity 没有通过，原因是 solver/runtime/provenance metadata 与正式 Windows 环境不同；论文和支撑材料不得声称“跨平台所有 JSON 字节完全一致”。

## 【治理限制】

PR #18 的最新 Review Artifact 已证明此前“legacy ZIP 不可得”的前提过期，并要求将该 PR 改写为 legacy archive → canonical workflow 的 coverage migration / retirement protocol。该治理线不修改本问 Frozen 数值。

当前 FYQ 窗口仍未直接获得两个 legacy ZIP 的 bytes，因此不声称本窗口已完成 legacy paper archive 的逐条 coverage audit。最终 Paper Lock / Submission Gate 前必须补齐该治理闭环。
